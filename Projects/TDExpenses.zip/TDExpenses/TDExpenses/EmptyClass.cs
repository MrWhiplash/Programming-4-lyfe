using System;

namespace TDExpenses
{
	public class EmptyClass
	{
		public EmptyClass ()
		{
		}
	}
}

